package com.fact.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fact.dao.DAO;
import com.fact.dao.FacDao;
import com.fact.model.Faculty;

import jakarta.servlet.http.HttpSession;

@Controller
public class FacultyController {

	@GetMapping("/admin")
	public String viewAdmin() {
		System.out.println("Inside ViewAdmin");
		return "adminHome";
	}

	@RequestMapping("/addfaculty")
	public String viewaddFaculty() {
		System.out.println("Inside ViewAdmin");

		return "addfaculty";
	}

	@GetMapping("/insertFaculty")
	public String insertFaculty(@ModelAttribute("insertFaculty") Faculty faculty, FacDao m) {

		System.out.print("Name = " + faculty.getFname());
		m.save(faculty);
		return "addfaculty";
	}

	@GetMapping("managefac")
	public String lodeFace(Model m, FacDao facDao) {

		List<Faculty> faclist = facDao.findAll();
		for (Faculty f : faclist) {
			System.out.println("Namw:" + f.fname);
		}
		m.addAttribute("employee", facDao.findAll());

		return "managefaculties";
	}

	@GetMapping("/deleteFaculty/{id}")
	public String deleteEmployee(@PathVariable int id, FacDao m) {

		m.deleteFaculty(id);

		return "redirect:/managefac";
	}

	@GetMapping("/editfac/{id}")
	public String lodeEditForm(@PathVariable(value = "id") int id, Model m, FacDao m1) {
		Faculty fac = m1.getEmpById(id);

		System.out.println(fac);
		m.addAttribute("employee", fac);

		return "editfaculty";

	}

	
	@PostMapping("/editfac/updateFaculty")
	public String updateFac(@ModelAttribute("updateFaculty") Faculty fac, FacDao dao) {
		System.out.println("Name : " + fac.getFname());
		System.out.println("Emil : " + fac.getFemail());
		System.out.println("id : " + fac.getId());
		
//		Faculty f = dao.getEmpById(fac.getId());
//		
//		if(f  == null){
//            System.err.println("Fac Not Found");
//          }
//		else
//		{
//			f.setFname(fac.getFname());
//			f.setFemail(fac.getFemail());
//			f.setFcontact(fac.getFcontact());
//			f.setFdepartment(fac.getFdepartment());
//			f.setFgender(fac.getFgender());
//			f.setFpass(fac.getFpass());
//			f.setFsalary(fac.getFsalary());
//			f.setId(fac.getId());
//			f.setVersion(fac.getVersion());
//
//			
//		}
		dao.updateFaculty(fac);

		return "redirect:/managefac";

	}

	@PostMapping("/updateFaculty")
	public String updateFac2(@ModelAttribute("updateFaculty") Faculty fac,Model m, FacDao dao) {

		dao.updateFaculty(fac);
		Faculty fac1 = dao.getEmpById(fac.getId());

		System.out.println(fac1);
		m.addAttribute("employee", fac1);
		return "facultyHome";

	}

	@RequestMapping("/login")
	public String loginuser(@RequestParam("email") String email, @RequestParam("pass") String pass, Model m,
			FacDao dao,HttpSession session) {
		List<Faculty> listf = dao.findAll();

		if (email.equals("admin@admin.com") && pass.equals("admin")) {
            session.setAttribute("loginId", "admin@admin.com");
			return "adminHome";
		} else {
			return checkFacLogin(listf, email, pass, m,session);
		}

	}

	private String checkFacLogin(List<Faculty> listf, String email, String pass, Model m,HttpSession session) {
		// TODO Auto-generated method stub
		boolean b = false;

		for (Faculty faculty : listf) {

			if (faculty.getFemail().equals(email) && faculty.getFpass().equals(pass)) {
				b = true;
				m.addAttribute("employee", faculty);
				break;

			}
		}
		if (b) {
            session.setAttribute("loginId", "admin@admin.com");
			return "facultyHome";

		} else {
			return "home";

		}
	}

	@RequestMapping("/")
	public String viewhome() {
		return "home";
	}

	@RequestMapping("/dashboard")
	public String viewDashboard() {
		return "adminHome";
	}

	@RequestMapping("/editfac/dashboard")
	public String viewDashboard2() {
		return "adminHome";
	}

	@RequestMapping("/editfac/addfaculty")
	public String viewaddFaculty2() {
		return "addfaculty";
	}

	@RequestMapping("/managefac")
	public String manageFac() {
		return "managefaculties";
	}

	@RequestMapping("/editfac/managefac")
	public String manageFac2() {
		return "redirect:/managefac";

	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
        session.invalidate();
		return "home";
	}


	@RequestMapping("/editfac/logout")
	public String logout2() {
		return "redirect:/";

	}

}
