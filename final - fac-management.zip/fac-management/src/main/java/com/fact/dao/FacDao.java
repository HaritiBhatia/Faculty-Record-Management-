package com.fact.dao;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.fact.model.Faculty;

import jakarta.persistence.criteria.CriteriaQuery;

@Repository
public class FacDao {

	public void save(Faculty faculty)
	{
		System.out.println("Faculty Dao");
		Session session = DAO.getSessionFactory().openSession();
		session.beginTransaction();
		session.persist(faculty);
		session.getTransaction().commit();
	}
	
    public List<Faculty> findAll() {
        Session session =  DAO.getSessionFactory().openSession();
        CriteriaQuery<Faculty> criteriaQuery = session.getCriteriaBuilder().createQuery(Faculty.class);
        criteriaQuery.from(Faculty.class);
        return session.createQuery(criteriaQuery).getResultList();
    }
    
    public void deleteFaculty(int id)
	{
    	Session session = DAO.getSessionFactory().openSession();
		session.beginTransaction();
		Faculty f = session.get(Faculty.class,id);
		session.delete(f);
		session.getTransaction().commit();

			
	}
    
    public Faculty getEmpById(long id)
	{
    	Session session = DAO.getSessionFactory().openSession();
		session.beginTransaction();
		Faculty f = session.load(Faculty.class, new Long(id));
		session.getTransaction().commit();
		return f;
	}
    
	public void updateFaculty(Faculty fac)
	{
		
		
		Session session = DAO.getSessionFactory().openSession();
		session.beginTransaction();
//		System.out.println("In Dao");
		System.out.println("Fac : " + fac.getId());
		Faculty f = session.load(Faculty.class, fac.getId());
		f.setFname(fac.getFname());
		f.setFemail(fac.getFemail());
		f.setFcontact(fac.getFcontact());
		f.setFdepartment(fac.getFdepartment());
		f.setFgender(fac.getFgender());
		f.setFpass(fac.getFpass());
		f.setFsalary(fac.getFsalary());
		session.update(f);
		session.getTransaction().commit();
	}
}
