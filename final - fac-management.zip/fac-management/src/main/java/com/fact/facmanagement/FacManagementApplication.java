package com.fact.facmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@SpringBootApplication(scanBasePackages = {"com.fact.controller","com.fact.model","com.fact.dao","com.fact.service"} )
public class FacManagementApplication {

 
	public static void main(String[] args) {
		SpringApplication.run(FacManagementApplication.class, args);
	}


	@RequestMapping("/home")
	public String viewpage()
	{
		return "Hello from Home";
	}
	
	
}
