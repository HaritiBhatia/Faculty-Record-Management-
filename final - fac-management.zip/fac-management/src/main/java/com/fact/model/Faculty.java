package com.fact.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Version;

@Entity
public class Faculty {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Version
	private Long version;

	
	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	public Faculty() {
		// TODO Auto-generated constructor stub
	}

	

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getFemail() {
		return femail;
	}

	public void setFemail(String femail) {
		this.femail = femail;
	}

	public String getFpass() {
		return fpass;
	}

	public void setFpass(String fpass) {
		this.fpass = fpass;
	}

	public String getFdepartment() {
		return fdepartment;
	}

	public void setFdepartment(String fdepartment) {
		this.fdepartment = fdepartment;
	}

	public String getFsalary() {
		return fsalary;
	}

	public void setFsalary(String fsalary) {
		this.fsalary = fsalary;
	}

	public String getFcontact() {
		return fcontact;
	}

	public void setFcontact(String fcontact) {
		this.fcontact = fcontact;
	}

	public String getFgender() {
		return fgender;
	}

	public void setFgender(String fgender) {
		this.fgender = fgender;
	}

	public String fname;
	String femail;
	String fpass;
	String fdepartment;
	String fsalary;
	String fcontact;
	String fgender;

}
