package com.fact.facmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
